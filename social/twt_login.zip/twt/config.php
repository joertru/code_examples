<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', '<ingrese consumer key>');
define('CONSUMER_SECRET', '<ingrese consumer secret>');
define('OAUTH_CALLBACK', 'http://parcehost.com/twt/callback.php');