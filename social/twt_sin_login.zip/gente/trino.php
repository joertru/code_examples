<?PHP
$mensaje=$_REQUEST['msg'];
$image=$_REQUEST['img'];

require 'twt/tmhOAuth.php';

$tmhOAuth = new tmhOAuth(array(
  'consumer_key'    => '',
  'consumer_secret' => '',
  'user_token'      => '',
  'user_secret'     => '',
));
 
 
$code = $tmhOAuth->user_request(array(
  'method' => 'POST',
  'url' => $tmhOAuth->url('1.1/statuses/update_with_media'),
  'params' => array(
    'media[]'  => "@{$image};type=image/jpeg;filename={$name}",
    'status'   => $mensaje,
  ),
  'multipart' => true,
));

print_r($code);
echo "\n\n\n\n\n\n********************\n\n\n\n\n\n\n";
print_r($tmhOAuth);
?>



